% This is the main script for a bayonet steam generator 
% funkar förhoppningsvis nu
clear all

L = 10
N = 500

d_lead_inner = 0.02; 
wall_thickness = 0.001;

d_w_o_o =    d_lead_inner - wall_thickness     % d outer for outer water

d_w_o_i = 0.004

d_w_i_o = d_w_o_i - wall_thickness

d_w_i_i = 0



mass_flow_water = 0.89/20; 
mass_flow_lead = 90;
rho_liquid = XSteam('rho_pT', 180, 340)
v_liquid_inner = 4*mass_flow_water/(rho_liquid *3.14*d_w_i_o*d_w_i_o)
A = pi*(d_w_o_o^2 - d_w_o_i^2)/4
v_liquid_outer = mass_flow_water / (rho_liquid * A)
v_lead = 1 
v = min([abs(v_lead), abs(v_liquid_outer), abs(v_liquid_inner)])
dt = L / (2*v*N)


h = XSteam('h_pt', 170, 340)
w_o = [h, 340, 170, v_liquid_outer, d_w_o_o, d_w_o_i, 0];
w_i = [h, 340, 170, v_liquid_inner, d_w_i_o, d_w_i_i, 0];

state_water_outer = repmat(w_o, N,1); 
state_water_inner = repmat(w_i, N,1); 

pb = [0, 530, 2, v_lead, 0, d_lead_inner, 1];

state_lead = repmat(pb, N,1); 



a = bayonet_find_equilibrium(state_lead, state_water_outer, state_water_inner, 500, dt, pb, w_i, mass_flow_water, mass_flow_lead, L); 



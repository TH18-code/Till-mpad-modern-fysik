function phase = get_phase(h, P)
% args: 
%   h - enthalpy (in KJ)
%   P - pressure (in bars)

%returns phase: 
%   1 -liquid, 2-boiling, 3-vapor


sat_vap_h=XSteam('hV_p',P);
sat_liq_h=XSteam('hL_p',P);


if h<=sat_liq_h
    phase = 1;
elseif h>sat_liq_h && h<sat_vap_h
    phase = 2;
else%if h>=sat_vap_h
    phase = 3;  
end


end

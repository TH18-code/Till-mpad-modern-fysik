function [state_1, state_2] = find_equilibrium(state1, state2, timesteps, dt, incoming_1, incoming_2, mass_flow_water, mass_flow_lead,L)
%seeks equilibrium and plots temperatures 
%         OBS!!!!
%         ASSUMES THAT MASSFLOWRATE OF LEAD = 900 KG/S
% 
% % args: 
% L   - Lenght for small discrete cylinder
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d1, type1]
%              |H2, T2, P2, v2, d2, type2|    
% statematrix =|.  .  .               .  |
%              |.  .  .               .  |
%              [Hn, Tn, Pn, vn, dn, typen]
% Returns:  0

shape1 = size(state1);
N = shape1(1);
x = linspace(0,30,N); % used for plotting later on

for t = 1:1:timesteps
    clf
    i = t
   
    % calculate changes in enthalpy
    q_vec = get_q_vector(state1, state2, L); 
    m1_vec=get_mass(state1,mass_flow_lead,mass_flow_water,L/N);
    m2_vec=get_mass(state2,mass_flow_lead,mass_flow_water,L/N);


    H_dot_1=q_vec./m1_vec;
    H_dot_2=q_vec./m2_vec;

    state1(:,1) = state1(:,1) - H_dot_1 * dt*20; % assuming 20 water pipes
    state2(:,1) = state2(:,1) + H_dot_2 * dt; 
    
    % take step forwards (move due to velocity of fluid)
    state1 = move_forward(state1, L, dt, incoming_1); 
    state2 = move_forward(state2, L, dt, incoming_2); 
    
    % calculate the new state values (Temp and velocities) 
    l = L / N;
    state1(:,2) = get_temperatures(state1, l);
    state2(:,2) = get_temperatures(state2, l);
    % if water then get new velocities
    if state1(1,end) == 0
        state1(:,4) = get_velocities(state1, mass_flow_water);
    end
    if state2(1,end) == 0
        state2(:,4) = get_velocities(state2,mass_flow_water);
    end
    
    % need to plot the new variables
    % want to plot temperatures over position
    
    plot(x,state1(:,2))
    hold on
    plot(x,state2(:,2))
    legend('1', '2')
    pause(0.1)

end 


plot(x,state1(:,2))
hold on
plot(x,state2(:,2))
legend('1', '2')

state_1 = state1;
state_2 = state2;
end 







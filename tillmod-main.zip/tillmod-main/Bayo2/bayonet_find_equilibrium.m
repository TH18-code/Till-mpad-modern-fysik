function [state_1, state_2,state_3] = bayonet_find_equilibrium(state1, state2, state3, timesteps, dt, incoming_lead, incoming_water, mass_flow_water, mass_flow_lead,L,number_of_tubes)
%seeks equilibrium and plots temperatures 
%         OBS!!!!
%         ASSUMES THAT MASSFLOWRATE OF LEAD = 900 KG/S
% 
% % args: 
% L   - Lenght for small discrete cylinder
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d_o1, d_i1 type1]
%              |H2, T2, P2, v2, d_o2, d_i2,type2|    
% statematrix =|.  .  .                      .  |
%              |.  .  .                      .  |
%              [Hn, Tn, Pn, vn, d_on, d_in,typen]
% Returns:  0

shape2 = size(state2);
N = shape2(1)
x = linspace(0,L,N);
d_inner = state2(1,6)
d_outer = state2(1,5)

for i = 1:timesteps
    clf
    disp(i)

    if i == 200
        t = i
    end
    
    % heat transfers
    q_vec_y = get_q_vector(state1, state2, L); 
    q_vec_i = get_q_vector(state2, state3, L); 
  

    m_lead = get_mass(state1, mass_flow_lead, mass_flow_water, L/N);
    m_outer_w = get_mass(state2, mass_flow_lead, mass_flow_water, L/N);
    m_inner_w = get_mass(state3, mass_flow_lead, mass_flow_water, L/N);
    
    H_dot_lead = -q_vec_y./m_lead; 
    H_dot_outer_w = (q_vec_y - q_vec_i)./m_outer_w; 
    H_dot_inner_w = q_vec_i./m_inner_w; 
    
    state1(:,1) = state1(:,1) + H_dot_lead * dt*number_of_tubes; 
    state2(:,1) = state2(:,1) + H_dot_outer_w * dt; 
    state3(:,1) = state3(:,1) + H_dot_inner_w * dt; 

    % move steps forward 
    % create large water matrix for timestep forward
    w_matrix = zeros([2*N, 7]);
    w_matrix(1:N,:) = state3; 
    w_matrix(N+1:end,:) = flip(state2); 
    
    state1 = move_forward(state1, L, dt, incoming_lead);
    w_matrix = move_forward(w_matrix,2*L, dt, incoming_water);  % 2L ty matrix is twotimes longer
   
    % recreate our 2 water state matrices for inner and outer 
    state2 = flip(w_matrix(N+1:end, :));
    state2(:, 6) = ones([N,1]).*d_inner;
    state2(:, 5) = ones([N,1]).*d_outer;
    state3 = w_matrix(1:N, :); 
    state3(:,6) = 0;
    
    % calculate the new state values (Temp and velocities) 
    l = L / N;
    state1(:,2) = get_temperatures(state1, l);
    state2(:,2) = get_temperatures(state2, l);
    state3(:,2) = get_temperatures(state3, l);

    if state2(1,end) == 0
        state2(:,4) = get_velocities(state2, mass_flow_water); % negative om vatten går upp
    end
    if state3(1,end) == 0
        state3(:,4) = get_velocities(state3,mass_flow_water);
    end
%   
    title('Temperature over Tube plot')
    xlabel('Length of tubes')
    ylabel('Temperature')

    plot(x,state1(:,2))
    hold on
    plot(x,state2(:,2))
    hold on
    plot(x,state3(:,2))
    legend('Lead', 'Outer Water','Inner water')
    pause(0.1)


end

    title('Temperature over Tube plot')
    xlabel('Length of tubes')
    ylabel('Temperature')
    plot(x,state1(:,2))
    hold on
    plot(x,state2(:,2))
    hold on
    plot(x,state3(:,2))
    legend('Lead', 'Outer Water','Inner water')



end 


%Exampleone double pipe HE
l = 1.5; %m pipe length
n = 10; % number of nodes used

dx = l/n; % Dividing length into nodes
time_final=1000; %seconds
dt=10; %seconds

x=linspace(0,l,n); %Array containing space between node 2 to n-1
T1=ones(1,n)*T0; %Initial conditions for all the nodes in geometry 1
T2=ones(1,n)*T0; %Initial conditions for all the nodes in geometry 2

dTdt1 = ones(1,n-2); %Rate of change in temerature of liquid 1
dTdt2 = ones(1,n-2); %Rate of change in temperature of liquid 2
t=0:dt:time_final; %array for time
for j=1:length(t)









    
    clf

    %Energy balance for fluid 1
    dTdt1(2:n)=(m1*Cp1*(T1(1:n-1)-T1(2:n))+U*2*pi*r1*dx*(T2(2:n)-T1(2:n)))/(rho1*Cp1*Ac1*dx);
    dTdt1(1)=(m1*Cp1*(T1in-T1(1))+U*2*pi*r1*dx*(T2(1)-T1(1)))/(rho1*Cp1*Ac1*dx);
    %Energy balance for fluid 2
    dTdt2(2:n)=(m2*Cp2*(T2(1:n-1)-T2(2:n))-U*2*pi*r1*dx*(T2(2:n)-T1(2:n)))/(rho2*Cp2*Ac2*dx);
    dTdt2(1)=(m2*Cp2*(T2in-T2(1))-U*2*pi*r1*dx*(T2(1)-T1(1)))/(rho2*Cp2*Ac2*dx);
    T1 = T1 + dTdt1 * dt; 
    T2 = T2 + dTdt2 * dt ;
   
    plot(x,T1,'-b','LineWidth',5)
    axis([0,80,290,365])
    xlabel('Distance (m)');
    ylabel('Temperature (K)');
    hold on
    plot(x,T2,'-r','LineWidth',5)
    pause(0.1)
end








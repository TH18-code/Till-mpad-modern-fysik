function [q] = get_q(state1,state2, L)
%get_q returns q for a layer
% arguments
%    statei: (T, P, v, d_0, d_i, Type)


%calc_h1

T1 = state1(1);
P1 = state1(2);

if state1(1,end) == 0 % 0 for water, 1 for lead
    h1 = XSteam('h_pt',P1,T1); 
    t = isnan(h1);
    if t == 1
        h1 = XSteam('h_pt',P1,T1 + 0.0004); % XSteam kan ta sig själv bakifrån om den skickar NaN nu
    end 
else
    h1 = 0; 
end

%state1 vector pushed to R_eff
s1 = [T1, P1, state1(1,3), h1, state1(1,5), state1(1,end)];  % antar att d behövs i R_eff


%calc h2
T2 = state2(1,1);
P2 = state2(1,2);

if state2(1,end) == 0 % 0 for water, 1 for lead
    h2 = XSteam('h_pt',P2,T2); 
    t = isnan(h2);
    if t == 1
        h2 = XSteam('h_pt',P2,T2 + 0.0004); % XSteam kan ta sig själv bakifrån om den skickar NaN nu
    end
else
    h2 = 0; 
end 


%state2_vector pushed to R_eff
s2 = [T2, P2, state2(1,3), h2, state2(1,4), state2(1,end)];



r_eff = Reff(s1,s2); 

% LMTD = ((T1 - T2_out) - (T1_out - T2))/log((T1 - T2_out)/(T1_out - T2));
TD = T1 - T2;

q = TD * L / r_eff;

end
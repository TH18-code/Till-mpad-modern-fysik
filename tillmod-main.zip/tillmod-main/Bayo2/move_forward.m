function state1_matrix= move_forward(mat_1,L,dt,first_1)
%Calculates the new positions for state matrix and returns a new state
%matrix
% 
% % args: 
%first_1 - h,T,p,v,d,type for new liquid coming in
% L   - Lenght for whole cylinder
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d_o1, d_i1 type1]
%              |H2, T2, P2, v2, d_o2, d_i2,type2|    
% statematrix =|.  .  .                      .  |
%              |.  .  .                      .  |
%              [Hn, Tn, Pn, vn, d_on, d_in,typen]
%
% Returns:  new state matrix after step
% 

shp1=size(mat_1);
state1_matrix=zeros(shp1);
N = shp1(1);
dx=L/N;
%h,t,p,v,d,type
vel1=mat_1(:,4);

d_inner = mat_1(end,6);


% if moving forwards, insert new element highest up, if moving backward, it
% should be inserted at the end
if vel1(1) > 0
    state1_matrix(1,:)=first_1;
else 
    state1_matrix(end,:)=first_1;
end

for i=1:1:N
    %figuring out the next row and moving the state to its new position
    vel=vel1(i);
    ds=vel*dt;
    n=round(ds/dx);
    if i+n<=N && i+n >= 1
        state1_matrix(i+n,:)=mat_1(i,:);
    end


end


% check the different velocities 
% if moving forwards
if vel1(1) > 0
    for i = N:-1:1
        if state1_matrix(i,:) == zeros(1,7)
            
            if i==N
                state1_matrix(i,:)=mat_1(i,:);
            else
                state1_matrix(i,:) = state1_matrix(i+1,:);
            end
        end
    end

% if moving backwards
else 
   for i = 1:1:N
    if state1_matrix(i,:) == zeros(1,7)
        
        if i==1
            state1_matrix(i,:)=mat_1(i,:);
        else
            state1_matrix(i,:) = state1_matrix(i-1,:);
        end
    end
end 

% if mat_1(1, end) == 0  % if it's water we need to set the inner diameter 
%     mat_1(N+1:end,6) = d_inner;
% end

end


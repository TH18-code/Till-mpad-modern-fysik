function [V] = get_velocities(state_matrix)
% Calculates new velocities for state_matrix as a function of the enthalpy 
% Obs: if the type is lead the velocity returned is just the input velocity
%       ASSUMES MASSFLOW RATE OF WATER = 900 kg/s
% args: 
% H   - Enthalpy
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d1, type1]
%              |H2, T2, P2, v2, d2, type2|    
% statematrix =|.  .  .               .  |
%              |.  .  .               .  |
%              [Hn, Tn, Pn, vn, dn, typen]
% Returns:  [v1]
%           |v2|   
%        T =| .|    
%           | .| 
%           [vn]


type = state_matrix(1,end); 

if type == 1; % if it's led we will just return the old velocity as we assume constant v for lead
    V = state_matrix(:,4);
else
% for water we need to calculate the phase of the water
% we will have stored values for the speed of water at the different phases
mass_flow = 1; 
rho_liquid = XSteam('rho_pT', 180, 340);
rho_steam = XSteam('rho_pT', 160, 530);
rho_boil = (rho_liquid + rho_steam)/2;
d = state_matrix(1,5);
v_liquid = 4*mass_flow/(rho_liquid *3.14*d*d);
v_boiling = 4*mass_flow/(rho_boil *3.14*d*d);
v_vapor = 4*mass_flow/(rho_steam *3.14*d*d);

phase_velocities = [v_liquid, v_boiling, v_vapor];

shape = size(state_matrix);
n = shape(1);
V = zeros([n, 1]);

for i = 1:n
    h_i = state_matrix(i,1);
    p = state_matrix(i,3);
    phase_i = get_phase(h_i, p); 
    V(i,1) = phase_velocities(phase_i);
end

end 
end


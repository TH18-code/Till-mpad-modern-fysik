# Source Code Tillämpad modern fysik 
This is is the source code for our optimization of a steam generator. It consists of different functions that get several parameters needed to perform calculations on heat transfer between the coolants. See report for further details. 

<img width="674" alt="Skärmavbild 2023-12-06 kl  16 17 59" src="https://gits-15.sys.kth.se/storage/user/18609/files/cf917aad-f7f9-4060-a435-698fc33e2077">


<img width="691" alt="Skärmavbild 2023-12-06 kl  16 20 29" src="https://gits-15.sys.kth.se/storage/user/18609/files/66c167d6-af2b-4137-b56d-7882c311aab2">

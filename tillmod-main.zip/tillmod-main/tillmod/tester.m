%alpha = get_alpha([25,1,2,XSteam('h_pT',1,25),1]);
T_in=340;
T_out=530;
p_in=180;
p_out=160;
h_in=XSteam('h_pT',p_in,T_in);
h_out=XSteam('h_pT',p_out,T_out);
P_th=1.6 *10^6;
mass_flow=P_th/((h_out-h_in)*10^3);

p = 170 
T = 320
rho= XSteam('rho_pT',p,T)  % funkar inte för boiling water
my=XSteam('my_pT',p,T)  % funkar inte för boiling water
Pr=XSteam('pr_pt',p,T) % funkar inte för boiling water
tc=XSteam('tc_pT',p,T) % funkar inte för boiling water


p = 170 
T = 400
rhov= XSteam('rho_pT',p,T)  % funkar inte för boiling water
myv=XSteam('my_pT',p,T)  % funkar inte för boiling water
Prv=XSteam('pr_pt',p,T) % funkar inte för boiling water
tcv=XSteam('tc_pT',p,T) % funkar inte för boiling water

rho = (rho + rhov)*0.5
my = (my + myv)*0.5 
Pr = (Prv + Pr)*0.5 
tc = (tc + tcv)*0.5





h = XSteam('h_pt', 170, 352.2934)
t = isnan(h)
if t == 1
 T = 352.2934 + 0.0001
end
h = XSteam('h_pt', 170, 352.2934 + T)
h =XSteam('h_pt', 1, 99);
% state2=[340, 170, 2, 0.4, 0];
% state1=[520, 2, 2, 0.402, 1];
% 
% q=get_q(state1,state2,0.01);
% 

% th_cond_pb= 17.257; %(W/mK) thermal conductivity for lead
% d_pb=1;  %ta den från state2 och check om type är 1
% u_pb=1; %hastighet
% th_diffu_pb= 1.161*10^(-5) %diffusivity (m^2/s)
% alpha_pb=(th_cond_pb/d_pb)*6+0.006*(th_cond_pb*u_pb/th_diffu_pb)

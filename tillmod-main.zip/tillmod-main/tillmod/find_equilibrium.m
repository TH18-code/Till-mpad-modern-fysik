function [state_1, state_2] = find_equilibrium(state1, state2, timesteps, dt, incoming_1, incoming_2)
%Calculates seeks equilibrium and plots events 
%         OBS!!!!
%         ASSUMES THAT MASSFLOWRATE OF LEAD = 900 KG/S
% 
% % args: 
% L   - Lenght for small discrete cylinder
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d1, type1]
%              |H2, T2, P2, v2, d2, type2|    
% statematrix =|.  .  .               .  |
%              |.  .  .               .  |
%              [Hn, Tn, Pn, vn, dn, typen]
% Returns:  0

shape1 = size(state1);
N = shape1(1);
x = linspace(0,30,N); % used for plotting later on
L = 100;

for t = 1:1:timesteps
    clf
    i = t
   
    % calculate changes in enthalpy
    H_dot = get_q_vector(state1, state2, L); 
    state1(:,1) = state1(:,1) - H_dot * dt*20;
    state2(:,1) = state2(:,1) + H_dot * dt*20; 
    
    % take step forwards (move due to velocity of fluid)
    state1 = move_forward(state1, L, dt, incoming_1); 
    state2 = move_forward(state2, L, dt, incoming_2); 
    
    % calculate the new state values (Temp and velocities) 
    l = L / N;
    state1(:,2) = get_temperatures(state1, l);
    state2(:,2) = get_temperatures(state2, l);
    % if water then get new velocities
    if state1(1,end) == 0
        state1(:,4) = get_velocities(state1);
    end
    if state2(1,end) == 0
        state2(:,4) = get_velocities(state2);
    end
    
    % need to plot the new variables
    % want to plot temperatures over position
    
    plot(x,state1(:,2))
    hold on
    plot(x,state2(:,2))
    legend('1', '2')
    pause(0.1)

end 
plot(x,state1(:,2))
hold on
plot(x,state2(:,2))
legend('1', '2')

state_1 = state1;
state_2 = state2;
end 







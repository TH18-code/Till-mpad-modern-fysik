function alpha = get_alpha(state_water)

%[T2, P2, state2(1,3), h2, state2(1,4), state2(1,end)];

T=state_water(1);
p=state_water(2);
v=state_water(3);
h=state_water(4);
d=state_water(5);
type=state_water(6);
L=d;

p=170;
sat_vap_h=XSteam('hV_p',p);
sat_liq_h=XSteam('hL_p',p);

%vapour_frac=XSteam('x_ph',p,h);
rho= XSteam('rho_pT',p,T);  % funkar inte för boiling water
my=XSteam('my_pT',p,T);  % funkar inte för boiling water
Pr=XSteam('pr_pt',p,T); % funkar inte för boiling water
tc=XSteam('tc_pT',p,T); % funkar inte för boiling water

t = isnan(rho); 
if t == 1; 
    T = T + 0.0001; 
    rho= XSteam('rho_pT',p,T);  % funkar inte för boiling water
    my=XSteam('my_pT',p,T);  % funkar inte för boiling water
    Pr=XSteam('pr_pt',p,T); % funkar inte för boiling water
    tc=XSteam('tc_pT',p,T);
end
Re=(rho*v*L)/my;

if h<=sat_liq_h
    Nu = 0.023*Re^(0.8)*Pr^(0.4);
elseif h>sat_liq_h && h<sat_vap_h
    Nu = 5*0.023*Re^(0.8)*Pr^(0.4);
else%if h>=sat_vap_h
    Nu = 0.0157*Re^(0.84)*Pr^(0.33);
end

alpha = Nu*tc/d;

end

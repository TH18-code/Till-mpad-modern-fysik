function [T] = get_temperatures(state_matrix, L)
%Calculates temperature for state_matrix as a function of the enthalpy 
%         OBS!!!!
%         ASSUMES THAT MASSFLOWRATE OF LEAD = 85 KG/S
% 
% % args: 
% L   - Lenght for small discrete cylinder
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d1, type1]
%              |H2, T2, P2, v2, d2, type2|    
% statematrix =|.  .  .               .  |
%              |.  .  .               .  |
%              [Hn, Tn, Pn, vn, dn, typen]
% Returns:  [T1]
%           |T2|   
%        T =| .|    
%           | .| 
%           [Tn]

shape = size(state_matrix);
n = shape(1);
T = zeros(n,1); 


if state_matrix(1,end) == 0    % 0 for water, 1 for lead
% do temperature calculation with XSteam for water

for i = 1:n
    h_i = state_matrix(i,1); 
    p_i = state_matrix(i,3); 
    T_i = XSteam('T_ph',p_i, h_i);
    T(i,1) = T_i;
end




else 
% do own calculations using thermodynamics for fluid dh = cmdT (under
% % constant pressure as dH = dU then)
% m_flow = 90; % need massf (kg /s)lead
% v = state_matrix(1,4);
% m = abs(m_flow * L / v);    % see Theos ipad for derrivation
c = 145/1000; % heat capacity for lead at that temperature (  kJ/(Kg*K)  )
T_in = 550;  % temperaure from lead entering the steamgenerator (obtained by Dmitry)
% 

for i = 1:n
    h_i = state_matrix(i,1);
    T_i_new = T_in + h_i / (c);
    T(i,1) = T_i_new;
end

end


end


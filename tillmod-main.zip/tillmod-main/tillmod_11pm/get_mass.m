function mass_vec=get_mass(state_mat,mass_flow_lead,mass_flow_water, l)
%takes in a state matrix and returns a column vector containing the mass
%for each row in the matrix
%2 scenarios lead and water
% length of discrete cylinder 
type=state_mat(1,end);
shape=size(state_mat)
N=shape(1)


if type==1  %lead
    v = state_mat(1,4);
    m = abs(mass_flow_lead * l / v);    % see Theos ipad for derrivation
    mass_vec = ones(N,1)*m;

elseif type==0
%     v=state_mat(:,4);
%     mass_vec = abs(mass_flow_water*l./v);
    m = abs(mass_flow_water* l / 8);    % see Theos ipad for derrivation
    mass_vec = ones(N,1)*m;

end
end
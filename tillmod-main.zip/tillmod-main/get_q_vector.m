function [q_vector] = get_q_vector(state_matrix_1,state_matrix_2, L)
%Calculates the q vector (q values for each cell) as a function of current states
% both statematrices needs to have matching dimensions (n rows, 5 columns)
% args: 
% L   - Lenght 
% T   - Temperature 
% P   - Pressure (assumed constant by us at 170 bars)
% v   - Speed for fluid
%type - Binary variable (0 for water, 1 for lead)
%
%              [H1, T1, P1, v1, d1, type1]
%              |H2, T2, P2, v2, d2, type2|    
% statematrix =|.  .  .               .  |
%              |.  .  .               .  |
%              [Hn, Tn, Pn, vn, dn, typen]
% Returns:  [q1]
%           |q2|   
%        q =| .|    
%           | .| 
%           [qn]


shape = size(state_matrix_1); 
% get amount of rows to loop over
n = shape(1); 

% create a standing q_vector with n rows
q_vector = zeros([n,1]); 
l = L/n;
for i = 1:n
    q_vector(i,1) = get_q(state_matrix_1(i,2:end), state_matrix_2(i,2:end), l);
end


end


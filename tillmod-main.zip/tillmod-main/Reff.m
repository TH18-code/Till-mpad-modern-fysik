function reff = Reff(state1, state2)

%thermal conductitivity wall
kt = 0.02;


%if water and lead
if state1(6) ~= state2(6)
%hlead
th_cond_pb= 0.017257; %(W/mK) thermal conductivity for lead
d_pb=state1(5);  %ta den från state2 och check om type är 1
u_pb=state1(3); %hastighet
th_diffu_pb= 1.16110^(-5); %diffusivity (m^2/s)
hout=(th_cond_pb/d_pb)*6+0.006*(th_cond_pb*u_pb/th_diffu_pb);

%hwater
hin = get_alpha(state2)*0.001; % changed here


elseif state1(6) == state2(6)
hin = get_alpha(state2)*0.001; % changed here
hout = get_alpha(state1)*0.001; % changed here
end

rin = state2(5) * 0.5;
rout = state1(5) * 0.5;

reff = 1/(2 * pi * rin * hin) + (log(rout/rin))/(2 * pi * kt) + 1/(2 * pi * rout * hout);

end
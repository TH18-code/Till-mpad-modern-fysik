% This is the main script for a cylindrical steam generator 



% To DO 
% initialize conditions for water 
% initialize conditions for lead 
% run find_equilibrium

d = 0.03
N = 2000
mass_flow = 1; 
rho_liquid = XSteam('rho_pT', 180, 340)
v_liquid = 4*mass_flow/(rho_liquid *3.14*d*d)

h = XSteam('h_pt', 170, 340)
w = [h, 340, 170, v_liquid, d, 0]

state_water = repmat(w, N,1);

% set up lead 
d_pb = d + 0.01;
pb = [0, 530, 2, -1, d_pb, 1];

state_lead = repmat(pb, N,1); 

a = find_equilibrium(state_lead, state_water, 500, 0.1, pb, w);
x = linspace(0,30,N);
state1 = a(1)
state1 = a(2)
plot(x,state1(:,2))
hold on
plot(x,state2(:,2))
legend('1', '2')

